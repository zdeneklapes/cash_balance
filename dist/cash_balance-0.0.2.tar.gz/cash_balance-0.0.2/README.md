# Cash Balance

This is a simple library to calculate a different type of loans.
