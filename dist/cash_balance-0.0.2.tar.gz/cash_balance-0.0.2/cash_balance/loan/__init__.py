from .loan import calculate_month_to_pay_loan, calculate_year_to_pay_loan

all = ['calculate_month_to_pay_loan', 'calculate_year_to_pay_loan']